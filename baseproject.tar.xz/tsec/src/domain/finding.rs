//! Findings, evidence and provenance.
//!
//! A *finding* is a single normalised fact that some tool actually reported.
//! The framework never invents one: every finding carries a [`Provenance`]
//! pointing at the provider, command, timestamp and artifact it came from, so
//! the operator can always verify the framework's interpretation against the
//! preserved raw evidence.

// Copyright (c) funbinet. All rights reserved.
// Part of TSEC terminal cybersecurity operations platform by funbinet.

use std::path::PathBuf;

use chrono::{DateTime, Utc};
use serde::{Deserialize, Serialize};

/// Classification of a harvested fact.
#[derive(Debug, Clone, Copy, PartialEq, Eq, PartialOrd, Ord, Hash, Serialize, Deserialize)]
pub enum Category {
    /// The operator's stated target.
    Target,
    /// A hostname or subdomain.
    Host,
    /// An IP address.
    Ip,
    /// A port number.
    Port,
    /// A named service.
    Service,
    /// A software or product version.
    Version,
    /// A detected technology or product.
    Technology,
    /// An HTTP(S) URL.
    Url,
    /// A specific API or administrative endpoint.
    Endpoint,
    /// A DNS record value.
    Dns,
    /// An HTTP status/header/title observation.
    Http,
    /// A TLS or certificate observation.
    Tls,
    /// A security finding raised by a scanning tool.
    Finding,
    /// A username and password seen together, e.g. `admin:hunter2`.
    Credential,
    /// An account name observed on the target.
    Username,
    /// A password, key, private key or connection string.
    Secret,
    /// An API key, bearer token or JWT.
    Token,
    /// Session material: cookies, session identifiers.
    Cookie,
    /// A password hash, ready for an offline attack.
    Hash,
    /// Shell material in evidence: a reverse-shell path, a spawned pty,
    /// a meterpreter string.
    Shell,
    /// A CVE or CWE identifier.
    Cve,
    /// A filesystem path, or a file whose exposure matters.
    File,
    /// A comment or annotation recovered from source, HTML or a config file.
    Comment,
    /// An email address.
    Email,
    /// A string matching the operator's declared CTF flag format.
    ///
    /// A candidate, never a verdict: a matching string may come from a banner,
    /// a fixture, or an unrelated file, so every sighting keeps its source and
    /// the report separates candidates from verified evidence. See
    /// [`crate::ctf`].
    FlagCandidate,
    /// A weaker flag-format signal: the prefix word mentioned bare, or a
    /// generic `word{body}` shape with an unrecognised prefix.
    ///
    /// A lead, not a candidate: it names the flag's vocabulary without
    /// producing a submittable value, and the report keeps leads below
    /// candidates. See [`crate::ctf`].
    FlagLead,
    /// Verbatim evidence retained from the raw stream.
    ///
    /// Counted and kept in `output.json`, never presented as a finding. A line
    /// the extractor does not recognise is not yet known to be nothing — but it
    /// is certainly not known to be intelligence either, and printing it in the
    /// document is what turned one misinvoked tool's `--help` output into twenty
    /// findings. An operator reading a document needs every line in it to be a
    /// claim about the target.
    Evidence,
    /// Tool progress, banners and timings.
    ///
    /// Counted, never presented. Progress chatter is the single largest source
    /// of noise in a multi-tool run: keeping it in the same bucket as real
    /// evidence is what makes a harvest look empty when it is not.
    Noise,
    /// Descriptive metadata about the tool or the run.
    Metadata,
    /// An error or diagnostic emitted by a tool.
    Error,
}

impl Category {
    /// Capitalised section heading used in the consolidated harvest.
    pub fn heading(self) -> &'static str {
        match self {
            Category::Target => "TARGET",
            Category::Host => "HOSTS",
            Category::Ip => "IP ADDRESSES",
            Category::Port => "PORTS",
            Category::Service => "SERVICES",
            Category::Version => "VERSIONS",
            Category::Technology => "TECHNOLOGIES",
            Category::Url => "URLS",
            Category::Endpoint => "ENDPOINTS",
            Category::Dns => "DNS RECORDS",
            Category::Http => "HTTP OBSERVATIONS",
            Category::Tls => "TLS OBSERVATIONS",
            Category::Finding => "FINDINGS",
            Category::Credential => "CREDENTIAL PAIRS",
            Category::Username => "USERNAMES",
            Category::Secret => "SECRETS",
            Category::Token => "TOKENS",
            Category::Cookie => "COOKIES",
            Category::Hash => "HASHES",
            Category::Shell => "SHELL MATERIAL",
            Category::Cve => "VULNERABILITIES",
            Category::File => "FILES",
            Category::Comment => "COMMENTS",
            Category::Email => "EMAILS",
            Category::FlagCandidate => "FLAG CANDIDATES",
            Category::FlagLead => "FLAG LEADS",
            Category::Evidence => "EVIDENCE",
            Category::Noise => "NOISE",
            Category::Metadata => "METADATA",
            Category::Error => "ERRORS",
        }
    }

    /// Presentation order in the consolidated harvest: high-signal first.
    ///
    /// Credentials and exploitable material sit above plain inventory because
    /// they are what changes what the operator does next. `Noise` sorts last so
    /// it can be excluded from the document without disturbing anything above.
    pub fn order(self) -> u8 {
        match self {
            Category::Finding => 0,
            Category::Secret => 1,
            Category::Token => 2,
            Category::Cookie => 3,
            Category::Hash => 4,
            Category::Shell => 4, // shell material ranks with hashes
            Category::Cve => 5,
            Category::Username => 6,
            Category::Credential => 7,
            Category::Target => 8,
            Category::Url => 9,
            Category::Endpoint => 10,
            Category::Host => 11,
            Category::Email => 12,
            Category::Ip => 13,
            Category::Port => 14,
            Category::Service => 15,
            Category::Version => 16,
            Category::Technology => 17,
            Category::File => 18,
            Category::Comment => 19,
            Category::Dns => 20,
            Category::Http => 21,
            Category::Tls => 22,
            Category::Evidence => 23,
            Category::FlagCandidate => 2, // flag candidates rank with credentials and tokens
            Category::FlagLead => 3,      // leads rank just under candidates
            Category::Metadata => 24,
            Category::Noise => 25,
            Category::Error => 26,
        }
    }

    /// Whether this category is an actionable artefact rather than narration.
    ///
    /// The distinction drives the document: an operator reading a harvest wants
    /// what they can act on, and wants the chatter that produced it available
    /// but not in the way.
    pub fn is_actionable(self) -> bool {
        !matches!(
            self,
            Category::Noise | Category::Metadata | Category::Error | Category::Evidence
        )
    }
}

/// Where a piece of harvested information came from.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct Provenance {
    pub provider: String,
    pub operation: String,
    pub task_id: String,
    /// Exact command that produced the information.
    pub command: String,
    pub observed_at: DateTime<Utc>,
    /// Raw evidence file backing this information.
    pub artifact: PathBuf,
    /// The network boundary the producing task ran behind.
    ///
    /// Part of provenance rather than presentation: a finding harvested from a
    /// local hash audit and one harvested through oniux are not the same claim,
    /// and the harvest must not silently present them as though they were.
    pub boundary: crate::domain::execution::ExecBoundary,
}

/// One normalised, traceable piece of harvested information.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct Finding {
    pub category: Category,
    /// The value as the tool reported it, unchanged.
    pub value: String,
    /// Optional structured attribute, e.g. `port 443/tcp on 10.0.0.1`.
    pub detail: Option<String>,
    pub provenance: Provenance,
    /// Number of times this value was observed across the run.
    pub occurrences: usize,
}

impl Provenance {
    /// Placeholder used while a harvest is being assembled, before it is
    /// attributed to the task that produced it.
    pub fn placeholder() -> Self {
        Self {
            provider: String::new(),
            operation: String::new(),
            task_id: String::new(),
            command: String::new(),
            observed_at: Utc::now(),
            artifact: PathBuf::new(),
            boundary: crate::domain::execution::ExecBoundary::Local,
        }
    }
}

impl Finding {
    /// Identity used for deduplication: category plus value, case-folded.
    pub fn dedup_key(&self) -> (Category, String) {
        (self.category, self.value.to_ascii_lowercase())
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn prov() -> Provenance {
        Provenance {
            boundary: crate::domain::execution::ExecBoundary::Oniux,
            provider: "httpx".into(),
            operation: "probe".into(),
            task_id: "T02".into(),
            command: "httpx -l ports.txt -silent".into(),
            observed_at: Utc::now(),
            artifact: PathBuf::from("/out/raw/httpx-probe.jsonl"),
        }
    }

    #[test]
    fn headings_are_uppercase_plural_labels() {
        assert_eq!(Category::Host.heading(), "HOSTS");
        assert_eq!(Category::Technology.heading(), "TECHNOLOGIES");
    }

    #[test]
    fn findings_sort_high_signal_first() {
        let mut cats = vec![Category::Evidence, Category::Finding, Category::Host];
        cats.sort_by_key(|c| c.order());
        assert_eq!(
            cats,
            vec![Category::Finding, Category::Host, Category::Evidence]
        );
    }

    #[test]
    fn dedup_key_is_case_insensitive_but_keeps_value() {
        let a = Finding {
            category: Category::Host,
            value: "API.Example.com".into(),
            detail: None,
            provenance: prov(),
            occurrences: 1,
        };
        let b = Finding {
            category: Category::Host,
            value: "api.example.com".into(),
            detail: Some("seen twice".into()),
            provenance: prov(),
            occurrences: 1,
        };
        assert_eq!(a.dedup_key(), b.dedup_key());
        assert_ne!(a.value, b.value);
    }
}
